package com.boot.sample.user;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.junit4.SpringRunner;

import com.boot.sample.entity.User;
import com.boot.sample.repos.UserRepository;

@RunWith(SpringRunner.class)
@SpringBootTest
public class DemoApplicationTests {

	@Autowired
	ApplicationContext context;

	@Test
	public void contextLoads() {
		UserRepository repository = context.getBean(UserRepository.class);
		
//		User user = new User();
//		
//		user.setUserid(12L);
//		user.setUsername("rash");
//		user.setPassword("rash");
//		user.setEmail("rash@gmail.com");
//		user.setFirstname("Rashmi");
//		user.setLastname("Vishwanath");
//		user.setPhonenumber("914576");
//		user.setSbaccBalance(1000);
//		user.setCaccBalance(2000);
//		user.setSbaccount(1457896);
//		user.setCaccount(125478);
		
		
	//	repository.save(user);
	}
}



