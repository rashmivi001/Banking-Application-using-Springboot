package com.boot.sample.controller;

import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.boot.sample.entity.Deposit;
import com.boot.sample.entity.TransferDetails;
import com.boot.sample.entity.User;
import com.boot.sample.services.Userservice;

/*********************************************************************************
 * 
 * @author Rashmi Vishwanath (G1801881J) 
 * Class: 		AdminController
 * Description: This is a Rest Controller class for Microservice part at Admin 
 * 				module - Deposit Amount and View User's information
 * 
 *********************************************************************************/

@org.springframework.web.bind.annotation.RestController
@CrossOrigin
@RequestMapping("/bank")
public class RestController<SearchCriteria> {
	
	@Autowired
	private Userservice  service;
	
	public Userservice getService() {
		return service;
	}

	public void setService(Userservice service) {
		this.service = service;
	}
	
	/*************************************************************************
	 * 
	 * @param request 	- HttpServletRequest Object
	 * @return			- It returns to an object with list of String values
	 * Description		- This is the microservice to fetch the user values 
	 * 					  from the DB based on the URL provided in the ajax
	 * 					
	 *************************************************************************/
	
	@GetMapping("/db/users/{userid}")
	public List<String> getUserInfo( @PathVariable("userid") int userid, HttpServletRequest request )
	{
		User _cUser = service.findByUserid( userid );
		List<String> _lUserList = new ArrayList<String>();
		if( null != _cUser )
		{
			Integer _iUserID = _cUser.getUserid();
			_lUserList.add( _iUserID.toString() );
			
			_lUserList.add( _cUser.getUsername() );
			
			Integer _iSBAccount = _cUser.getSbaccount();
			_lUserList.add( _iSBAccount.toString() );
			
			Integer _iSBBalance = _cUser.getSbaccBalance();
			_lUserList.add( _iSBBalance.toString() );
			
			Integer _iCAccount = _cUser.getCaccount();
			_lUserList.add( _iCAccount.toString() );
			
			Integer _iCAccBalance = _cUser.getCaccBalance();
			_lUserList.add( _iCAccBalance.toString() );
		}
		
		request.setAttribute("mode","MODE_REGISTER");
		return _lUserList;
	}

	/*To run in Browser*/
	@RequestMapping("/hello")
	public ModelAndView Hello()
	{
		ModelAndView mv = new ModelAndView();
		mv.setViewName("userinfo");
		return mv;
	}
	
	
	/*************************************************************************
	 * 
	 * @param request 	- HttpServletRequest Object
	 * @return			- It returns a success message OK 
	 * Description		- This is the microservice to save the values 
	 * 					  into the DB based on the URL provided in the ajax
	 * 					
	 *************************************************************************/
	
	@PostMapping("/deposit-amounts")
    public String depositPOST(@RequestBody Deposit deposit,HttpServletRequest request) 		  
	{
		service.deposit(deposit.getUserid(),deposit.getSrcAccType(),request,deposit.getAmount());
        return "Ok";
    }
	
	
	/*************************************************************************
	 * 
	 * @param request 		- HttpServletRequest Object
	 * @return				- It returns a success and failure message based on 
	 * 					  		the condition 
	 * @param PathVariable	- It fetches userid value entered in the postman
	 * Description			- This is the microservice to update and save the values 
	 * 					 		into the DB.It uses postman to execute
	 * 					
	 *************************************************************************/
	
	@PutMapping("/TransferBetweenAccount/{userid}")
	public String betweenaccountpage( @RequestBody TransferDetails transferdetails,@PathVariable("userid") int userid,HttpSession session, HttpServletRequest request ) 
	{
		if( true == service.transfer(transferdetails,request,userid) )
		{
			return "Success";	
		}
		else
		{
			return "fail";
		}
	}
	
	/*************************************************************************
	 * 
	 * @param request 		- HttpServletRequest Object
	 * @return				- It returns a success and failure message based on 
	 * 					  		the condition 
	 * @param PathVariable	- It fetches recID value entered in the postman
	 * @param session		- Session context for the current execution of Application
	 * Description			- This is the microservice to delete the record 
	 * 					 		from the DB.It uses postman to execute
	 * 					
	 *************************************************************************/
	
	@DeleteMapping("/delete-recipient/{recID}")
	public String deleteRecipient(@PathVariable int recID, HttpServletRequest request, HttpSession session)
	{
		service.deleteMyRecipient(recID);
		return "Deleted";
	}

	
}