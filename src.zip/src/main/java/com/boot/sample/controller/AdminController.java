package com.boot.sample.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

import com.boot.sample.entity.Admin;
import com.boot.sample.services.Adminservice;

/*********************************************************************************
 * 
 * @author Rashmi Vishwanath (G1801881J) 
 * Class: 		AdminController
 * Description: This is a Controller class for Admin related UI operations like 
 * 					Admin-Login, Account-Deposit, View-Users-Info
 * 
 *********************************************************************************/
@Controller
public class AdminController 
{
	@Autowired
	private Adminservice service;
	
	/****************************************************************************************************
	 * 
	 * @param request 	- HttpServletRequest 
	 * @return			- String ("index"). It returns to index.jsp page after execution of this function
	 * Description		- This Controller is triggered when Admin login into the application
	 * 
	 ****************************************************************************************************/
	@RequestMapping("/adminlogin")
	public String adminLoginPage( HttpServletRequest request ) 
	{
		request.setAttribute("mode", "MODE_ADMINLOGIN");
		return "index";
	}
	
	/**********************************************************************************************
	 * 
	 * @param admin		- Object of type Class Admin containing Admin Username and Admin Password
	 * @param request	- HttpServletRequest
	 * @param session	- Session context for the current execution of Application
	 * @return			- String. Returns either "admin.jsp" or "index.jsp"
	 * Description		- This function validates Admin username and password. If it is succes, it
	 * 						allows the Admin user to enter into application
	 * 
	 ***********************************************************************************************/
	@RequestMapping("/adminlogin-user")
	public String adminLoginUser( @ModelAttribute Admin admin, HttpServletRequest request, HttpSession session )
	{
		String username = admin.getUsername();
		session.setAttribute( "newUsername", username );
		if( service.findByUsernameAndPassword( admin.getUsername(), admin.getPassword() ) != null ) 
		{
			//** Success case where a valid username and password is matched in the database.
			return "admin";
		}
		else 
		{
			//** Failure case where the entered credentials is not available in database
			request.setAttribute( "error", "Invalid Username or Password" );
			request.setAttribute( "mode", "MODE_ADMINLOGIN" );
			return "index";
		}
	}
	
	/**************************************************************************************
	 * 
	 * @param request 	- HttpServletRequest 
	 * @return			- String. Returns to admin.jsp page with Mode_DepositUserInfo view
	 * Description		- Returns to admin.jsp
	 *  
	 **************************************************************************************/
	@RequestMapping("/userinfo")
	public String userInfoSelected( HttpServletRequest request ) 
	{
		request.setAttribute("mode", "MODE_DEPOSITUSERINFO");
		return "admin";
	}
		
	/**********************************************************************
	 * 
	 * @param request	- HttpServerletRequest
	 * @return			- Returns to admin.jsp page with Mode_Deposit view
	 **********************************************************************/
	@RequestMapping("/deposit")
	public String depositAmountToUser( HttpServletRequest request ) 
	{
		request.setAttribute("mode", "MODE_DEPOSIT");
		return "admin";
	}
}