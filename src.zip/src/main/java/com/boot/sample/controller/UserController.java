package com.boot.sample.controller;

//** Imports used by the class UserController
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.validation.BindingResult;
import com.boot.sample.entity.Recipient;
import com.boot.sample.entity.TransferDetails;
import com.boot.sample.entity.User;
import com.boot.sample.services.Userservice;

/********************************************************************************************
 * 
 * @author Rashmi Vishwanath (G1801881J) 
 * Class		- UserController
 * Description	- This is the Controller Class for all User related UI operations.
 * 					like Registration, Login, Transfer Amount, Update Profile, Logout 
 *
 *********************************************************************************************/
@Controller
public class UserController {
	static int lastUserID;
	private static int nextSBAccountNumber = 1000;
	private static int nextCAccountNumber = 2000;
	
	//** Below functions are small and self explanatory. Hence, function header is not available.
	public static int getLastUserID() {
		return lastUserID;
	}

	public static void setLastUserID(int lastUserID) {
		UserController.lastUserID = lastUserID;
	}

	public static void setNextSBAccountNumber(int nextSBAccountNumber) {
		UserController.nextSBAccountNumber = nextSBAccountNumber;
	}

	public static void setNextCAccountNumber(int nextCAccountNumber) {
		UserController.nextCAccountNumber = nextCAccountNumber;
	}
	
	int getSBAccountNumber( ) {
		return ++nextSBAccountNumber;
	}
	
	int getCAccountNumber( ) {
		return ++nextCAccountNumber;
	}

	@Autowired
	private Userservice service;

	public Userservice getService() 
	{
		return service;
	}

	public void setService(Userservice service) 
	{
		this.service = service;
	}

	/*************************************************************************
	 * 
	 * @param request 	- HttpServletRequest Object
	 * @return			- It returns to index.jsp page which is the main page.
	 * Description		- This is the first page where user will enter once 
	 * 						login is success.
	 *************************************************************************/
	@RequestMapping("/")
	public String welcome( HttpServletRequest request ) 
	{
		request.setAttribute("mode","MODE_HOME");
		return "index";
	}
	
	/***************************************************************************
	 * 
	 * @param request	- HttpServletRequest object
	 * @return			- It returns to home.jsp page
	 * Description		- This function will return to home page of the users. 
	 * 
	 ***************************************************************************/
	@RequestMapping("/home")
	public String Home(HttpServletRequest request) 
	{		
		return "home";
	}
		
	/************************************************************************
	 * 
	 * @param request	- HttpServletRequest
	 * @return			- Return to index.jsp with the view Mode_Login. 
	 *************************************************************************/
	@RequestMapping("/userlogin")
	public String login( HttpServletRequest request ) 
	{
		request.setAttribute( "mode", "MODE_LOGIN" );
		return "index";
	}
	
	/*********************************************************************************************************
	 * 
	 * @param user		- Object of type Class User
	 * @param request	- HttpServletRequest
	 * @param session	- HttpSession Object for the current execution of application
	 * @return			- Returns to either home.jsp page or index.jsp page with Mode_Login view
	 * Description		- This function validates credentials provided by user. 
	 * 						If credentials are valid, User is entered into application or stays in Login page
	 * 
	 ********************************************************************************************************/
	@RequestMapping("/login-user")
	public String loginUser( @ModelAttribute User user, HttpServletRequest request, HttpSession session ) 
	{
		int userid = user.getUserid();
		session.setAttribute("newUserID", userid);
		if( service.findByUseridAndPassword( user.getUserid(), user.getPassword() ) != null ) 
		{
			//** Success case, User is allowed inside the home page. 
			return "home";
		}
		else 
		{
			//** Failure case where error is shown and stays in Login page.
			request.setAttribute( "error", "Invalid Username or Password" );
			request.setAttribute( "mode", "MODE_LOGIN" );
			return "index";
		}
	}
	
	/*************************************************************************
	 * 
	 * @param request	- HttpServletRequest
	 * @return			- Returns to index.jsp page with Mode_Register view.
	 * Description		- This function returns to new User Registration page. 
	 * 
	 *************************************************************************/
	@RequestMapping("/userregister")
	public String registerUser( HttpServletRequest request ) 
	{
		request.setAttribute( "mode","MODE_REGISTER" );
		return "index";
	}
	 
	/****************************************************************************************
	 * 
	 * @param user		- Object of type Class User
	 * @param request	- HttpServletRequest
	 * @return			- Returns to index.jsp page.
	 * Description		- This function creates a new entry into database for the User
	 * 						and returns unique generated UserID if success or failure message
	 * 
	 *****************************************************************************************/
	@RequestMapping( value = "/register-user", method = RequestMethod.POST )
	public String registeredUser( @ModelAttribute("user") User user, HttpServletRequest request ) 
	{
		//** Get last SB and Current Account number generated and store in the class.
		setNextSBAccountNumber( service.getSBAccNum() );
		setNextCAccountNumber( service.getCAccNum() );
		
		//** Generate new SB and Current Account Numbers
		user.setSbaccount( getSBAccountNumber( ) );
		user.setCaccount( getCAccountNumber( ) );
		
		//** Save User into database. 
		service.registerUser(user,request);
		return "index";
	}
	
	/****************************************************************************************
	 * 
	 * @param session	- HttpSession object for the current execution of the application
	 * @param request	- HttpServeletRequest
	 * @return			- Returns to home.jsp page with the view MODE_UPDATE
	 * Description		- This function fetches the current user details and sends to home.jsp 
	 * 						with the view MODE_UPDATE for updation of fields.
	 * 
	 *****************************************************************************************/
	@RequestMapping("/edit-user")
	public String editUser( HttpSession session, HttpServletRequest request ) 
	{
		Integer userID = ( Integer )session.getAttribute( "newUserID" );
		service.edituser( userID, request );
		return "home";
	}
	
	/*************************************************************************************
	 * 
	 * @param newUser	- Updated object of type Class User to be saved
	 * @param session	- HttpSession object for the current execution of application
	 * @return			- Returns profile.jsp page
	 * Description		- This function takes updated values from jsp page and updates the 
	 * 						user content in the database. 
	 * 
	 ************************************************************************************/
	@RequestMapping(value = "/save-user")
	public String updateProfilePage( @ModelAttribute("user") User newUser, BindingResult result, 
			HttpSession session, HttpServletRequest request ) 
	{
		Integer userID = ( Integer )session.getAttribute( "newUserID" );
		User olduser = service.findByUserid( userID );
		newUser.setUserid( userID );
		
		newUser.setUserid( olduser.getUserid() );
		newUser.setCaccount( olduser.getCaccount() );
		newUser.setSbaccount( olduser.getSbaccount() );
		newUser.setSbaccBalance( olduser.getSbaccBalance() );
		newUser.setCaccBalance( olduser.getCaccBalance() );
		
		if( null != service.saveMyUser( newUser ) )
		{
			request.setAttribute( "msg", "Profile has been updated successfully" );
		}
		else
		{
			request.setAttribute( "msg", "Profile updation failed" );
		}
	    return "profile";
	}

	/**************************************************************************************
	 * 
	 * @param request	- HttpServletRequest Object
	 * @return			- Returns to accounts.jsp page with the view MODE_BETWEENACCOUNTS
	 * Description		- This function returns to display accounts.jsp page and this page
	 * 						shows the fields to enter values for Src and Dst Account Type
	 *  					and the amount to transfer
	 * 
	 ***************************************************************************************/
	@RequestMapping("/betweenaccountUser")
	public String betweenaccountUser( HttpServletRequest request ) 
	{
		request.setAttribute( "mode", "MODE_BETWEENACCOUNTS" );
		return "Accounts";
	}

	/*******************************************************************************************
	 * 
	 * @param transferdetails	- Object of type Class TransferDetails
	 * @param session			- Object for current session of the application 
	 * @param request			- HttpServletRequest Object
	 * @return					- Returns to accounts.jsp page 
	 * Description				- This function execute the functionality of transferring amount 
	 * 								between account of the same user.
	 * 
	 *******************************************************************************************/
	@PostMapping("/betweenaccountpage")
	public String betweenAccountPage( @ModelAttribute("transferdetails") TransferDetails transferdetails,
			HttpSession session, HttpServletRequest request ) 
	{
		Integer userID = ( Integer )session.getAttribute( "newUserID" );
		service.transfer(transferdetails,request,userID);
		return "Accounts";
	}

	/******************************************************************************************
	 * 
	 * @param session	- HttpSession Object for the current application context
	 * @param request	- HttpServletRequest object
	 * @return			- Returns to account.jsp page with the view MODE_ADDRECIPIENT
	 * Description		- This function returns to accounts.jsp where the values of the
	 * 						new recipient can be added. 
	 * 						
	 *******************************************************************************************/
	@RequestMapping("/recipientpage")
	public String addRecipientPage( HttpSession session, HttpServletRequest request ) 
	{
	    request.setAttribute("mode","MODE_ADDRECIPIENT");
		return "Accounts";
	}
	
	/************************************************************************************
	 * 
	 * @param recipient		- Object of type Class Recipient which needs to be added
	 * @param session		- Session object for the current application context.
	 * @param request		- HttpServletRequest object
	 * @return				- Returns to accounts.jsp for adding new recipient
	 * Description			- This function creates a new Recipient for the current user
	 * 							and allows to add additional recipient if needed
	 * 
	 ************************************************************************************/
	@PostMapping("/recipientUser")
	public String addRecipientUser(@ModelAttribute("recipient") Recipient recipient, 
			HttpSession session, HttpServletRequest request ) 
	{
		Integer userID = ( Integer )session.getAttribute( "newUserID" );
		recipient.setUserID(  userID );
	    if( null != service.saveMyRecipient(recipient) )
	    {
		    int recid = recipient.getRecID();
			session.setAttribute("newRecID", recid);
		    request.setAttribute("msg", "Recipient has been added successfully");
	    }
	    else
	    {
	    	request.setAttribute("msg", "Failed to add new Recipient. Please try again");
	    }
	    request.setAttribute("mode","MODE_ADDRECIPIENT");
		return "Accounts";
	}
	
	/*************************************************************************************
	 * 
	 * @param request	- HttpServletRequest object
	 * @param session	- HttpSession object for the current application context
	 * @return			- Returns to home.jsp page with view ALL_RECIPIENTS
	 * Description		- This function fetches all the recipients for the current userID
	 * 						and sends to home.jsp page to display in UI.
	 * 
	 **************************************************************************************/
	@GetMapping("/showrecipients")
	public String showAllRecipients( HttpServletRequest request,HttpSession session ) 
	{
		Integer userID = ( Integer )session.getAttribute( "newUserID" );
		request.setAttribute("recipients",service.getAllRecipient(userID));
		request.setAttribute("mode","ALL_RECIPIENTS");
		return "home";
	}
	
	/**********************************************************************************
	 * 
	 * @param recID		- Recipient ID to be edited.
	 * @param request	- HttpServletRequest object
	 * @param session	- HttpSession Object for the current application context
	 * @return			- Returns to home.jsp page with the view MODE_UPDATERECIPIENT
	 * Description		- This function fetches all the contents of Recipient and sends to
	 * 						home.jsp page and displays in UI for editing. 
	 *  
	 ***********************************************************************************/
	@RequestMapping("/edit-recipient")
	public String editRecipient(@RequestParam int recID, HttpServletRequest request, HttpSession session) 
	{
		request.setAttribute("recipient", service.findRecipient(recID));
		request.setAttribute("mode", "MODE_UPDATERECIPIENT");
		return "home";
	}
		
	/************************************************************************************
	 * 
	 * @param recipient		- Object of type Class Recipient containing updated values
	 * @param request		- HttpServletRequest object
	 * @param session		- HttpSession Object for the current application context
	 * @return				- Returns to home.jsp page.
	 * Description			- This function fetches the updated values of Recipient and 
	 * 							saves into the database.
	 *************************************************************************************/
	@PostMapping("/save-recipient")
	public String recipientpage( @ModelAttribute Recipient recipient, BindingResult result, 
			HttpServletRequest request,HttpSession session ) 
	{
		Integer recID = ( Integer )session.getAttribute("newRecID");
		Integer userID = ( Integer )session.getAttribute("newUserID");
		recipient.setUserID(userID);
		service.saveMyRecipient(recipient);
		return "home";
	}
	
	/************************************************************************************
	 * 
	 * @param recID			- Recipient ID to be deleted from database
	 * @param request		- HttpServletRequest object
	 * @param session		- HttpSession Object for the current application context
	 * @return				- Returns to home.jsp page with the view ALL_RECIPIENTS
	 * Description			- This function deletes the selected recipeint from database.
	 * 
	 *************************************************************************************/
	@RequestMapping("/delete-recipient")
	public String deleteRecipient( @RequestParam int recID, HttpServletRequest request, HttpSession session ) 
	{
		Integer userID = ( Integer )session.getAttribute( "newUserID" );
		service.deleteMyRecipient(recID);
		request.setAttribute("recipients",service.getAllRecipient(userID));
		request.setAttribute("mode","ALL_RECIPIENTS");
		return "home";
	}

	/*************************************************************************************
	 * 
	 * @param request		- HttpServletRequest object
	 * @param session		- HttpSession Object for the current application context
	 * @return				- Returns to accounts.jsp page with the view MODE_TOSOMEONE
	 * Description			- This function returns to accounts.jsp page with the list of 
	 * 							Recipient's firstname
	 *  
	 *************************************************************************************/
	@RequestMapping("/tosomeonepage")
	public String toSomeoneUser( HttpServletRequest request, HttpSession session ) 
	{
		Integer userID = ( Integer )session.getAttribute( "newUserID" );
		List<String> recfname = service.getRecFirstName( userID );
		request.setAttribute( "recipientNameList", recfname );
		request.setAttribute( "mode", "MODE_TOSOMEONE" );
		return "Accounts";	
	}
	
	/**************************************************************************************************
	 * 
	 * @param transferDetails	- Object of type TransferDetails containing the transferring details
	 * @param request			- HttpServletRequest object
	 * @param session			- HttpSession Object for the current application context
	 * @return					- Returns to accounts.jsp page with error/success messages of transfer
	 * Description				- This function will check the pre-conditions of transfer and initiate
	 * 								transfer. If everything is success, then it give success message
	 * 								or error message if something wrong.
	 * 
	 ***************************************************************************************************/
	@PostMapping("/userfrontpage")
	public String transferToRecipient( @ModelAttribute("transferDetails") TransferDetails transferDetails, 
			HttpSession session, HttpServletRequest request ) 
	{
		Integer userID = ( Integer )session.getAttribute( "newUserID" );
	    service.toSomeone( transferDetails, request, userID );
		return "Accounts";
	}	
	
	/*******************************************************************************************************
	 * 
	 * @param request	- HttpServletRequest object
	 * @param session	- HttpSession Object for the current application context
	 * @return			- Returns to accounts.jsp page with basic account information.
	 * Description		- This function fetches basic account informations and send to jsp to display in UI.
	 * 
	 ********************************************************************************************************/
	@RequestMapping("/accountDetails")
	public String showAccountDetails( HttpSession session, HttpServletRequest request) 
	{
		Integer userID = ( Integer )session.getAttribute( "newUserID" );
        service.accountdetails(userID,request);
		return "Accounts";
	}
	
	/*******************************************************************************************************
	 * 
	 * @param userid	- UserID contents to display in UI
	 * @param request	- HttpServletRequest object
	 * @return			- Returns to userinfo.jsp page with the information of this user
	 * Description		- This method is using Microservices, returns the jsp page which has 
	 * 						ajax with rest controller URL
	 * 
	 ********************************************************************************************************/
	@PostMapping("/adminuserinfo")
    public String userinfoPOST(@RequestParam("userid") int userid,HttpServletRequest request ) 
	{
		service.adminuserinfo(userid,request);
		return "userinfo";
	}
	
	/******************************************************************************
	 * 
	 * @param session	- HttpSession Object to Invalidate.
	 * @return			- Logout.jsp page
	 * Description		- This function will invalidate HttpSession and logout user
	 * 
	 *******************************************************************************/
	@RequestMapping("/logoutPage")
	public String showindexPage(HttpSession session) 
	{
		session.invalidate(); 
		return "Logout";
	}
	
	/**********************************************************************************
	 * 
	 * @param request	- HttpServletRequest Object
	 * @return			- Returns to deposit.jsp
	 * Description		- This function will return to deposit.jsp page where ajax code
	 * 						for Rest API is executed and update the user with deposited 
	 * 						amount.
	 * 
	 ***********************************************************************************/
	@GetMapping("/deposit-page")
	public String depositPOST(HttpServletRequest request)
  	{
		request.setAttribute("mode","MODE_DEPOSIT");
		return "deposit";
  	}
}