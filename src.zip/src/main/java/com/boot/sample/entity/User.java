package com.boot.sample.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Entity
@Table(name="userDB")
@Component
@Scope("session")
public class User {

	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
		private int userid;
		private String username;
		private String password;
		private String firstname;
		private String lastname;
		private String email;
		private String phonenumber;
		private int sbaccount;
		private int caccount;
		private int sbaccbalance;
		private int caccbalance;
		
		//** Constructor
		public User(String username, String password, String firstname, String lastname, String email,
				String phonenumber, int sbaccount, int caccount, int sbaccbalance, int caccbalance) 
		{
			super();
			this.username = username;
			this.password = password;
			this.firstname = firstname;
			this.lastname = lastname;
			this.email = email;
			this.phonenumber = phonenumber;
			this.sbaccount = sbaccount;
			this.caccount = caccount;
			this.sbaccbalance = sbaccbalance;
			this.caccbalance = caccbalance;
		}
		
		public User()
		{
			
		}
		
		//** Getter and Setter functions
		public int getUserid() {
			return userid;
		}
		public void setUserid(int userid) {
			this.userid = userid;
		}
		public String getUsername() {
			return username;
		}
		public void setUsername(String username) {
			this.username = username;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public String getFirstname() {
			return firstname;
		}
		public void setFirstname(String firstname) {
			this.firstname = firstname;
		}
		public String getLastname() {
			return lastname;
		}
		public void setLastname(String lastname) {
			this.lastname = lastname;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public String getPhonenumber() {
			return phonenumber;
		}
		public void setPhonenumber(String phonenumber) {
			this.phonenumber = phonenumber;
		}
		public int getSbaccount() {
			return sbaccount;
		}
		public void setSbaccount(int sbaccount) {
			this.sbaccount = sbaccount;
		}
		public int getCaccount() {
			return caccount;
		}
		public void setCaccount(int caccount) {
			this.caccount = caccount;
		}
		public int getSbaccBalance() {
			return sbaccbalance;
		}
		public void setSbaccBalance(int sbaccBalance) {
			this.sbaccbalance = sbaccBalance;
		}
		public int getCaccBalance() {
			return caccbalance;
		}
		public void setCaccBalance(int caccBalance) {
			this.caccbalance = caccBalance;
		}
		@Override
		public String toString() {
			return "User [userid=" + userid + ", username=" + username + ", password=" + password + ", firstname="
					+ firstname + ", lastname=" + lastname + ", email=" + email + ", phonenumber=" + phonenumber
					+ ", sbaccount=" + sbaccount + ", caccount=" + caccount + ", sbaccBalance=" + sbaccbalance
					+ ", caccBalance=" + caccbalance + "]";
		}
}