package com.boot.sample.entity;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope("session")
public class TransferDetails {
	private String srcAccType;
	private String destAccType;
	private int amount;
	
	public String getSrcAccType() {
		return srcAccType;
	}
	public void setSrcAccType(String srcAccType) {
		this.srcAccType = srcAccType;
	}
	public String getDestAccType() {
		return destAccType;
	}
	public void setDestAccType(String destAccType) {
		this.destAccType = destAccType;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
}