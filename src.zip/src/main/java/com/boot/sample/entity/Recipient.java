package com.boot.sample.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="recipient")
public class Recipient {
    private int userID;
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int recID;
	private String firstname;
    private String lastname;
    private String email;
    private String phonenumber;
    private String acctype;
    private int accnumber;

    @ManyToOne
    @JoinColumn(name = "userID", referencedColumnName = "userID", insertable = false, updatable = false)
    private User user;

    public int getRecID() {
		return recID;
	}

	public void setRecID(int recID) {
		this.recID = recID;
	}
    
	public User getUser() {
		return user;
	}
	
	public int getUserID() {
		return userID;
	}

	public void setUserID(int userID) {
		this.userID = userID;
	}

	public String getFirstName() {
		return firstname;
	}

	public void setFirstName(String firstName) {
		this.firstname = firstName;
	}

	public String getLastName() {
		return lastname;
	}

	public void setLastName(String lastName) {
		this.lastname = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNumber() {
		return phonenumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phonenumber = phoneNumber;
	}

	public String getAccType() {
		return acctype;
	}

	public void setAccType(String accType) {
		this.acctype = accType;
	}

	public int getAccNumber() {
		return accnumber;
	}

	public void setAccNumber(int accNumber) {
		this.accnumber = accNumber;
	}

	public void setUser(User user) {
		this.user = user;
	}
	
	@Override
	public String toString() {
		return "Recipient [userID=" + userID + ", firstName=" + firstname + ", lastName=" + lastname + ", email="
				+ email + ", phoneNumber=" + phonenumber + ", accType=" + acctype + ", accNumber=" + accnumber
				+ ", user=" + user + "]";
	}
}