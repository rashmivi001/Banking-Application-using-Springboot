package com.boot.sample.repos;

import java.util.List;
import org.springframework.data.repository.CrudRepository;
import com.boot.sample.entity.Recipient;

public interface RecipientRepository extends CrudRepository<Recipient, Integer> {	
	public Recipient findByrecID(int recID);
	public List<Recipient> findByuserID(int userID);
	public Recipient save(Integer recID);
	public List<Recipient> findAllByuserID(int userID);
	public List<Recipient> findAllByfirstname(Integer userID);
}