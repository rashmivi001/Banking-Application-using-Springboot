package com.boot.sample.repos;

import org.springframework.data.repository.CrudRepository;
import com.boot.sample.entity.User;

public interface UserRepository extends CrudRepository<User, Integer> {
	public User findByUseridAndPassword(int userid,String password);
	public User findByUserid(int userid);
	public User findByUsernameAndPassword(String username,String password);	
}