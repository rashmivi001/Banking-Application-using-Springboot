package com.boot.sample.repos;

import org.springframework.data.repository.CrudRepository;
import com.boot.sample.entity.Admin;

public interface AdminRepository extends CrudRepository<Admin, String> {
	public Admin findByUsernameAndPassword(String username,String password);
}