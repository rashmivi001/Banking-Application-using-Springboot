package com.boot.sample.repos;

import org.springframework.data.repository.CrudRepository;
import com.boot.sample.entity.Deposit;

public interface DepositRepository extends CrudRepository<Deposit, Integer>
{
	public Deposit findByUserid(int userid);
}