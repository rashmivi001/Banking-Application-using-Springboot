package com.boot.sample.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import javax.servlet.http.HttpServletRequest;
import javax.transaction.Transactional;
import org.springframework.stereotype.Service;

import com.boot.sample.entity.Deposit;
import com.boot.sample.entity.Recipient;
import com.boot.sample.entity.TransferDetails;
import com.boot.sample.entity.User;

import com.boot.sample.repos.*;

/*******************
 * 
 * @author Rashmi Vishwanath (G1801881J) 
 * Class		- Userservice
 * Description	- This class contains the business logic related to User for the application.
 *
 */
@Service
@Transactional
public class Userservice 
{
	private final UserRepository userRepository;
	private final RecipientRepository recpRepo;
	private final DepositRepository DepRepo;
	
	/*********************************************************************
	 * 
	 * @param userRepository	- User Repository Class object
	 * @param recpRepo			- Recipient Repository Class object
	 * @param DepRepo			- Deposit Repository Class object
	 * Description				- Constructor for the Class Userservice
	 **********************************************************************/
	public Userservice( UserRepository userRepository, RecipientRepository recpRepo, DepositRepository DepRepo )
	{
		this.userRepository = userRepository;
		this.recpRepo = recpRepo;	
		this.DepRepo = DepRepo;
	}
	
	/*****************************************************************************************
	 * 
	 * @param user	- Object of type Class User to be created/updated in the database
	 * @return		- Return null if failed to create/update otherwise a valid object
	 * Description	- This function is used to create a new entry or update an existing entry
	 * 					into the table "User"
	 * 
	 ****************************************************************************************/
	public User saveMyUser( User user )
	{
		return userRepository.save( user );
	}

	/****************************************************************************************
	 * 
	 * @param recp	- Object of type Class Recipient to be created/updated in the database
	 * @return		- Return null if failed to create/update otherwise a valid object
	 * Description	- This function is used to create a new entry or update an existing entry
	 * 					into the table "Recipient"
	 * 
	 *****************************************************************************************/
	public Recipient saveMyRecipient(Recipient recp)
	{
		return recpRepo.save(recp);
	}	
	
	/**************************************************************************************
	 * 
	 * @param recID	- Recipient ID to be searched
	 * @return		- Valid object if search is success else null 
	 * DEscription	- This function searches Recipient table for the given recID parameter. 
	 * 
	 ***************************************************************************************/
	public Recipient findRecipient(int recID)
	{
		return recpRepo.findByrecID(recID);
	}

	/*************************************************************************************
	 * 
	 * @param userID	- User ID 
	 * @return			- Returns List of Recipients 
	 * Description		- This function is used to get all the recipients for the given 
	 * 						userID.
	 * 
	 *************************************************************************************/
	public List<Recipient> getAllRecipient(int userID)
	{
		List<Recipient> recipients=new ArrayList<Recipient>();
		for(Recipient recipient:recpRepo.findAllByuserID(userID))
		{
			recipients.add(recipient);
		}
		return recipients;
	}

	/************************************************************************************
	 * 
	 * @param recID	- Recipient ID to be deleted
	 * Description	- This function is used to delete the Recipeint for the given recID
	 * 
	 *************************************************************************************/
	public void deleteMyRecipient(int recID)
	{
		recpRepo.deleteById(recID);
	}
	
	/************************************************************************************
	 * 
	 * @param userid	- User ID to be updated
	 * @return			- Null if fails to updated else a valid User Object
	 * Description		- This function is used to update User details in the table User
	 * 
	 ************************************************************************************/
	public Optional<User> editUser(int userid) {
		return userRepository.findById(userid);
	}
	
	/************************************************************************************
	 * 
	 * @param user		- User to be updated
	 * @return			- Null if fails to updated else a valid User Object
	 * Description		- This function is used to update User details in the table User
	 * 
	 ************************************************************************************/
	public Iterable<User> editUsers(User user) {
		return userRepository.findAll();
	}
	
	/************************************************************************************
	 * 
	 * @return		- It returns all the Users
	 * Description	- This function returns all the users from the table "User"
	 * 
	 *************************************************************************************/
	public Iterable<User> findAllUsers() {
		return userRepository.findAll();
	}

	/************************************************************************************
	 * 
	 * @param userid	- UserID provided for login
	 * @param password	- Password provided for login
	 * @return			- Null if credentials doesn't match else a valid User Object
	 * Description		- This function is used to search the User table for the given
	 * 						userid and password. 
	 * 
	 *************************************************************************************/
	public User findByUseridAndPassword(int userid,String password)
	{
		return userRepository.findByUseridAndPassword(userid, password);
	}

	/*************************************************************************************
	 * 
	 * @param userid	- UserID to be searched.
	 * @return			- Returns Null if UserId is not found else a valid User object
	 * Description		- Search User table with "userid" and return the User object
	 * 
	 **************************************************************************************/
	public User findByUserid(int userid)
	{
		return userRepository.findByUserid(userid);
	}
	public Deposit findByDepUserid(int userid)
	{
		return DepRepo.findByUserid(userid);
	}
	
	/*************************************************************************************
	 * 
	 * @return		- Returns the last used SB account number
	 * Description	- This function fetches the last used SB account number from the table.
	 *  
	 **************************************************************************************/
	public int getSBAccNum()
	{
		Iterable<User> userList = findAllUsers( );
		int lastSBAccNum = 1;
		for(User p : userList)
		{
			if( p != null )
			{
				lastSBAccNum = p.getSbaccount();
			}
		}
		return lastSBAccNum;
	}
	
	/*******************************************************************************************
	 * 
	 * @return		- Returns the last used Current account number
	 * Description	- This function fetches the last used Current account number from the table.
	 * 
	 *******************************************************************************************/
	public int getCAccNum()
	{
		Iterable<User> userList = findAllUsers( );
		int lastCAccNum = 1;
		for(User p : userList)
		{
			if( p != null )
			{
				lastCAccNum = p.getCaccount();
			}
		}
		return lastCAccNum;
	}
	
	/**************************************************************************************
	 * 
	 * @param userID	- Recipient list for the userid
	 * @return			- Returns Recipient list.
	 * 
	 ************************************************************************************/
	public List<Recipient> getFirstName(Integer userID) 
	{
		List<Recipient> recFirstName = recpRepo.findAllByfirstname(userID);
		return recFirstName;
	}

	/**************************************************************************************
	 * 
	 * @param userID	- Recipient list for the userid
	 * @return			- Returns Recipient list.
	 * Description		- This function returns the list of FirstName of all the recipients
	 * 						for the give userID
	 * 
	 ************************************************************************************/
	public List<String> getRecFirstName(int userID)
	{
		List<Recipient> recip=getAllRecipient(userID);
		List<String> recfname = new ArrayList<String>();
		for(Recipient user : recip) 
		{
			recfname.add(user.getFirstName());
		}
		return recfname;
	}
	
	/************************************************************************************
	 * 
	 * @param username	- username to search
	 * @param password	- Password to search
	 * @return			- Null if credentials doesn't match else a valid User Object
	 * Description		- This function is used to search the User table for the given
	 * 						username and password. 
	 * 
	 *************************************************************************************/
	public User findByUsernameAndPassword(String username,String password)
	{
		return userRepository.findByUsernameAndPassword(username,password);
	}
	
	/***************************************************************************************************
	 * 
	 * @param transferdetails	- Object of type TransferDetails
	 * @param request			- HttpServletRequest Object
	 * @param userID			- User ID of the current user logged-in
	 * @return					- Success of Failure of transferring amount between accounts
	 * Description				- This function has business logic for account transfer between 
	 * 								the accounts. It validates all the pre-conditions before initiating 
	 * 								transfer and updates the database.
	 ****************************************************************************************************/
	public boolean transfer( TransferDetails transferdetails, HttpServletRequest request, int userID  )
	{
		boolean flag=false;   	
	  	if( (0 == transferdetails.getSrcAccType().compareTo("Savings")) && (0 == transferdetails.getDestAccType().compareTo("Savings") ) )
		{
			request.setAttribute("error", "Both Account type cannot be same");
			request.setAttribute("mode", "MODE_BETWEENACCOUNTS");
		} 	
		else if( (0 == transferdetails.getSrcAccType().compareTo("Savings")) && (0 == transferdetails.getDestAccType().compareTo("Current")))
		{
			User user = findByUserid( userID );
			int updatedsavAccBal, savAccBal = user.getSbaccBalance();
			int updateCAccBal, cAccBal = user.getCaccBalance();
			if( savAccBal >= transferdetails.getAmount() )
			{
				flag=true;
				updatedsavAccBal = savAccBal - transferdetails.getAmount();
				updateCAccBal = cAccBal + transferdetails.getAmount();
				user.setSbaccBalance(updatedsavAccBal);
				user.setCaccBalance(updateCAccBal);
				editUser(userID);
			    request.setAttribute("SBAccount", user.getSbaccount());
				request.setAttribute("SBAccBalance", user.getSbaccBalance());
				request.setAttribute("CAccount", user.getCaccount());
				request.setAttribute("CAccBalance", user.getCaccBalance()); 
				request.setAttribute("mode","MODE_DISPLAYACCOUNTS");	
			}
			else
			{
				request.setAttribute("error", "No enough balance in Savings Account");
				request.setAttribute("mode", "MODE_BETWEENACCOUNTS");
			}
		}
		else if( (0 == transferdetails.getSrcAccType().compareTo("Current")) && (0 == transferdetails.getDestAccType().compareTo("Savings")))
		{
			
			User user = findByUserid( userID );
			int updatedsavAccBal, savAccBal = user.getSbaccBalance();
			int updateCAccBal, cAccBal = user.getCaccBalance();	
			if( cAccBal >= transferdetails.getAmount() )
			{
				flag=true;
				updatedsavAccBal = savAccBal + transferdetails.getAmount();
				updateCAccBal = cAccBal - transferdetails.getAmount();
				user.setSbaccBalance(updatedsavAccBal);
				user.setCaccBalance(updateCAccBal);
				editUser(userID);
				request.setAttribute("SBAccount", user.getSbaccount());
				request.setAttribute("SBAccBalance", user.getSbaccBalance());
				request.setAttribute("CAccount", user.getCaccount());
				request.setAttribute("CAccBalance", user.getCaccBalance());
			    request.setAttribute("mode","MODE_DISPLAYACCOUNTS");
			}
			else
			{
				request.setAttribute("error", "No enough balance in Current Account");
				List<String> recfname=getRecFirstName(userID);
				request.setAttribute("recipientNameList", recfname);
				request.setAttribute("mode", "MODE_BETWEENACCOUNTS");
			}
				
		}
	  	return flag;
	}
		
	/***************************************************************************************************
	 * 
	 * @param transferDetails	- Object of type TransferDetails.
	 * @param request			- HttpServletRequest Object
	 * @param userID			- User ID of the currently logged-in user.
	 * Description				- This function contains the business logic for transferring amount to 
	 * 								a recipient available for the user.
	 * 
	 ****************************************************************************************************/
	public void toSomeone(TransferDetails transferDetails,HttpServletRequest request,int userID)
	{
		User user = findByUserid( userID );
		if( 0 == transferDetails.getDestAccType().compareTo("Savings") )
		{
			if( transferDetails.getAmount() < user.getSbaccBalance() )
			{
				user.setSbaccBalance( user.getSbaccBalance() - transferDetails.getAmount());
		    	editUsers(user);
				request.setAttribute("SBAccount", user.getSbaccount());
			    request.setAttribute("SBAccBalance", user.getSbaccBalance());
				request.setAttribute("CAccount", user.getCaccount());
				request.setAttribute("CAccBalance", user.getCaccBalance());    
			    request.setAttribute("mode","MODE_DISPLAYACCOUNTS");
			}
			else
			{
				request.setAttribute("error", "No enough balance to transfer");
				List<String> recfname=getRecFirstName(userID);
				request.setAttribute("recipientNameList", recfname);
				request.setAttribute("mode", "MODE_TOSOMEONE");
			}
		}
		else if( 0 == transferDetails.getDestAccType().compareTo("Current") )
		{
			if( transferDetails.getAmount() < user.getCaccBalance() )
			{
				 user.setCaccBalance( user.getCaccBalance() - transferDetails.getAmount());
				 editUsers(user);
				 request.setAttribute("SBAccount", user.getSbaccount());
				 request.setAttribute("SBAccBalance", user.getSbaccBalance());
				 request.setAttribute("CAccount", user.getCaccount());
				 request.setAttribute("CAccBalance", user.getCaccBalance());        
				 request.setAttribute("mode","MODE_DISPLAYACCOUNTS");
			}
			else
			{
			     request.setAttribute("error", "No enough balance to transfer");
				 List<String> recfname=getRecFirstName(userID);
				 request.setAttribute("recipientNameList", recfname);
				 request.setAttribute("mode", "MODE_TOSOMEONE");
			}
		}
	}

	/***************************************************************************************************
	 * 
	 * @param userid		- User ID to deposit amount
	 * @param srcAccType	- Account Type for the deposit
	 * @param request		- HttpServletRequest Object
	 * @param Amount		- Amount to deposit.
	 * Description			- This function contains business logic for depositing amount to an account
	 * 							by Admin user. 
	 * 
	 ****************************************************************************************************/
	public void deposit(int userid,String srcAccType,HttpServletRequest request,int Amount)
	{
		User user= findByUserid(userid);
		if(user!=null)
		{
			if(0== srcAccType.compareTo("Savings"))
			{
				int updatedsavAccAmount,savAccBal = user.getSbaccBalance();
				updatedsavAccAmount=savAccBal+Amount;
				user.setSbaccBalance(updatedsavAccAmount);
				request.setAttribute("msg", "Amount has been deposited successfully");
				saveMyUser(user);
			}
			else if(0==srcAccType.compareTo("Current"))
			{
			   	int updatedcurAccAmount,curAccBal = user.getCaccBalance();
				updatedcurAccAmount=curAccBal+Amount;
				user.setCaccBalance(updatedcurAccAmount);
				request.setAttribute("msg", "Amount has been deposited successfully");
				saveMyUser(user);
				}
			
			}
		else
		{
			request.setAttribute("error", "User doesn't exist");
		}
	}
		
	/*****************************************************************************************************
	 * 
	 * @param userid	- User ID to be displayed
	 * @param request	- HttpServletRequest object
	 * Description		- This function is used to fetch the details of the userid and send to admin page 
	 * 						for displaying the details of user
	 * 
	 ******************************************************************************************************/
	public void adminuserinfo(int userid,HttpServletRequest request )
	{
		User users= findByUserid(userid);
		if(users!=null)
		{
			request.setAttribute("userid", users.getUserid());
			request.setAttribute("username", users.getUsername());
			request.setAttribute("SBAccount", users.getSbaccount());
			request.setAttribute("SBAccBalance", users.getSbaccBalance());
			request.setAttribute("CAccount", users.getCaccount());
			request.setAttribute("CAccBalance", users.getCaccBalance()); 
			request.setAttribute("mode", "USERINFO");
		}
		else
		{
			request.setAttribute("error", "User doesn't exist");
			request.setAttribute("mode", "MODE_DEPOSITUSERINFO");		
		}
	}
		
	/***************************************************************************************************
	 * 
	 * @param userid	- User ID to be updated
	 * @param request	- HttpServletRequest object
	 * Description		- This function is used to update the user details in the table "user".
	 * 
	 ****************************************************************************************************/
	public void edituser( int userid, HttpServletRequest request )
	{
	    User user = findByUserid( userid );
	    request.setAttribute("firstname",user.getFirstname());
	    request.setAttribute("Password",user.getPassword());
	    request.setAttribute("username",user.getUsername());
	    request.setAttribute("LastName", user.getLastname());
	    request.setAttribute("Email", user.getEmail());
	    request.setAttribute("PhoneNumber", user.getPhonenumber());
		request.setAttribute("mode", "MODE_UPDATE");
	}	
	
	/***************************************************************************************************
	 * 
	 * @param user		- User Details to be created/updated
	 * @param request	- HttpServletRequest object
	 * Description		- This function is used to create a new entry or update an existing entry 
	 * 						in the table "User" for new registration.
	 * 
	 ****************************************************************************************************/
	public void registerUser(User user,HttpServletRequest request)
	{
	    if( null != saveMyUser(user) )
	    {
			int lastUserID = user.getUserid();
			request.setAttribute( "info", "User created successfully,Your userid is " + lastUserID );
			request.setAttribute( "mode", "MODE_HOME" );
	    }
	    else
	    {
	    	request.setAttribute( "info", "User creation failed. Try again" );
			request.setAttribute( "mode", "MODE_HOME" );
	    }
	}
		
	/***************************************************************************************************
	 * 
	 * @param userid	- User ID 
	 * @param request	- HttpServletRequest Object
	 * Description		- This function is used to fetch details of User and send basic information of
	 * 						the user to jsp page to display in UI.
	 * 
	 ****************************************************************************************************/
	public void accountdetails(int userid,HttpServletRequest request)
	{
		User existuser= findByUserid( userid );	    
		request.setAttribute("SBAccount", existuser.getSbaccount());
		request.setAttribute("SBAccBalance", existuser.getSbaccBalance());
		request.setAttribute("CAccount", existuser.getCaccount());
		request.setAttribute("CAccBalance", existuser.getCaccBalance());
		request.setAttribute("mode","MODE_DISPLAYACCOUNTS");
	}
}