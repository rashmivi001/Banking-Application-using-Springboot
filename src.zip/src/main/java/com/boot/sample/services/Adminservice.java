package com.boot.sample.services;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.boot.sample.entity.Admin;
import com.boot.sample.repos.AdminRepository;

/*******************
 * 
 * @author Rashmi Vishwanath (G1801881J) 
 * Class		- Userservice
 * Description	- This class contains the business logic related to Admin for the application.
 *
 */

@Service
@Transactional
public class Adminservice {

	private final AdminRepository adminRepository;
	
	/*********************************************************************
	 * 
	 * @param adminRepository
	 * Description	- Parameterized Constructor for the Class Adminservice
	 *   
	 *********************************************************************/
	
	public Adminservice( AdminRepository adminRepository  )
	{
		this.adminRepository=adminRepository;
	}
	
	/*********************************************************************
	 * 
	 * @param username - username provided for login
	 * @param password - Password provided for login
	 * @return 		   - Null if credentials doesn't match else a valid Admin Object
	 * Description	   - This function is used to search the Admin table for the given
	 * 						username and password 
	 * 
	 *********************************************************************/
	
	public Admin findByUsernameAndPassword(String username,String password)
	{
		return adminRepository.findByUsernameAndPassword(username,password);
	}	
}